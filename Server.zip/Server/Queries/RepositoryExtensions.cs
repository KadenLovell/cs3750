namespace Server.Persistence {
    public static partial class RepositoryExtensions { }
}