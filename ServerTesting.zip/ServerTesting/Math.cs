﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Text;

namespace ServerTesting
{
    class Math
    {
        public int add(int numOne, int numTwo) {
            return numOne + numTwo;
        }
    }
}
