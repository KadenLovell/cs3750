using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.EntityFrameworkCore;
using Server.Models;
using Server.Controllers;
using System;
using Server.Persistence;
using System.Threading.Tasks;
using System.Data.Entity.Infrastructure;

namespace ServerTesting
{
    [TestClass]
    public class UnitTest1
    {
        public DbContext _context { get; private set; }

        [TestMethod]
        public async Task TitleAssignmentTestAsync()
        {
            DbContextOptions<DataContext> options = new DbContextOptions<DataContext>();
            DbContextOptionsBuilder builder = new DbContextOptionsBuilder(options);
            SqlServerDbContextOptionsExtensions.UseSqlServer(builder, "Data Source=localhost;Initial Catalog=LMS-sandbox;Integrated Security=True;MultipleActiveResultSets=True;", null);
            _context = new DataContext((DbContextOptions<DataContext>)builder.Options);
        }
        [TestMethod]
        public void PointsAssignmentTest()
        {
            Assignment pointsAssignment = new Assignment();
            pointsAssignment.MaxPoints = 50;
            Assert.AreEqual(pointsAssignment.MaxPoints, 50);
        }
        [TestMethod]
        public async Task AssignmentCourseNameTest()
        {
            DbContextOptions<DataContext> options = new DbContextOptions<DataContext>();
            DbContextOptionsBuilder builder = new DbContextOptionsBuilder(options);
            SqlServerDbContextOptionsExtensions.UseSqlServer(builder, "Data Source=localhost;Initial Catalog=LMS-sandbox;Integrated Security=True;MultipleActiveResultSets=True;", null);
            _context = new DataContext((DbContextOptions<DataContext>)builder.Options);
            Course course = new Course();
            course.Name = "Math";
            _context.AddAsync(course);
            Assignment titleAssignment = new Assignment();
            titleAssignment.Course = course;
            titleAssignment.Title = "New Assignment";
            _context.AddAsync(titleAssignment);
            Assert.AreEqual(titleAssignment.Course.Name, "Math");
        }
    }
}
